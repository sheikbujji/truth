readme.txt file for XAPP213: PicoBlaze Soft Processor
--------------------------------

ISE Release 2.   December 2002

Macro Version v1.00c
Assembler Version v1.10


This is the first official release of the ISE version of the PicoBlaze soft processor 
for Virtex, Virtex-E, Spartan-II and Spartan-IIE devices consistent 
with the publication of version 2.0 of XAPP213 dated December 17th, 2002.


Welcome
-------

Welcome to this release of the ISE compatible version of the PicoBlaze Soft Processor. If you have not used 
a PicoBlaze Soft Processor macro before, then please take a while to scan this file and then turn to the 
XAPP213.pdf on the Xilinx web site to learn more about the macro and how to use it. If you intend to use
the Virtex-II architectures, then you should obtain a copy of XAPP627 rather than this 
version.

If you are an existing PicoBlaze Soft Processor user, then I hope you will find this version very familiar,
but hopefully much easier to use with the ISE tools we have today. Please take a while 
to look at the revised XAPP213.pdf to understand the new macro and design 
flow. The PicoBlaze Soft Processor is now supplied as VHDL and the new assembler also generates VHDL for the 
program ROM so there is no more EDIF! All VHDL can be synthesised and simulated. This 
PicoBlaze Soft Processor macro is code compatible with previous versions, but you will see that I/O names 
have changed slightly and it now has a reset control. The assembler now supports register 
naming but should process all existing code.

There are quite a lot of files in this package, but many of them are design examples and 
other macros which I hope you will find useful. These include compact UART macros, a small
FIFO buffer, and a utility to help extend program space to 512 locations.

I wish you success in your next project and I look forward to hearing your feedback.

Ken Chapman
email: chapman@xilinx.com 
Staff Engineer - Applications Specialist
Xilinx Ltd (UK)


Quick Description
-----------------

The PicoBlaze Soft Processor is a very simple 8-bit micro controller designed to be 100% 
embedded into a Virtex, Virtex-E, Spartan-II, or Spartan-II device. The PicoBlaze 
Soft Processor features 16 general purpose registers. A simple ALU supporting ADD/SUB, 
logical, shifts and rotates, conditional jumps and nested subroutine calls. 
Controls include a reset and an interrupt with associated instructions. 

The PicoBlaze Soft Processor was first released in May 1999 and has increased in 
popularity with the passing years. The original version is detailed in XAPP213 and
can still be used in designs today. However, the Xilinx design tools have evolved since 1999
and this version has been made to be compatible with the ISE tools based on VHDL files.

The PicoBlaze Soft Processor assembler is supplied to assist in the development of programs. 

Performance >40 MIPS. Best of all, it uses just 76 slices (fit 8 in an XC2S50E and still have
21% of the device left over).

Documentation is provided in XAPP213.pdf on the Xilinx web site.


Verification and Testing
------------------------

The PicoBlaze Soft Processor has now been used thousands of times and is very stable. 
However, this is very much a new implementation with new tools so it is expected 
that different issues will be reported. My thanks go out to existing PicoBlaze 
Soft Processor users for helping verify this new version so far and I am
pleased that you have had no significant problems. There is now high confidence that
this is a fully working solution. Since it is virtually impossible to verify every 
combination of events that a processor may encounter, your help is requested in 
continuing to verify the functionality of the macro and assembler. All reports are 
welcomed by the author (hopefully good reports as well as any issues or recommendations). 

Please send your reports via email to: chapman@xilinx.com

 
PicoBlaze Soft Processor Macro Revision History
----------------------------

V1.00c - First ISE release to users.


PicoBlaze Soft Processor Assembler Revision History
--------------------------------

V1.10  - First release to users with improved (and corrected) template files.


Contents
--------

This package contains many files, but don't panic, many of them are additional 
files which I hope you will find useful reference.


readme.txt - This file


Main PicoBlaze Soft Processor Files
----------------

kcpsm.vhd. - The vhdl definition of the PicoBlaze Soft Processor. This file is the 
             primary design flow for implementation and simulation. The use of 
             this file is described in the documentation.

kcpsm.ngc - This is an alternative file defining the PicoBlaze Soft Processor and 
            would be used as a "black box" in a non vhdl design flow.

kcspm_embedded - VHDL file in which the PicoBlaze soft processor is connected to its 
                 associated program ROM. This can be used as example code and 
                 is described in the documentation.   
               
KCPSM.EXE - The assembler for PicoBlaze Soft Processor programs.

ROM_form.vhd - VHDL template file read by the assembler and used to define the 
               style in which the program ROM will be implemented. This file 
               must be placed in the same working directory as KCPSM.EXE.

ROM_form.coe - Coefficient template file read by the assembler and used to define
               the style in which the program ROM will be implemented via the 
               Core Generator flow. This file must be placed in the same working
               directory as KCPSM.EXE.

int_test.psm - Example PSM file as used in the documentation.

kcpsm_int_test.vhd - Example design VHDL file as used in the documentation.

test_bench.vhd - Example VHDL test bench to use with kcpsm_int_test.vhd to 
                 reproduce the wave forms seen in the documentation.


Bonus Files
-----------

PSMSPLIT.EXE - Utility program to generate double size program memory with bank switching.

psmsplit.vhd - VHDL template file read by the PSMSPLIT utility. This file must be placed in 
               the same directory as the utility program.

kcpsm_split_rom.vhd - Example design in which PSMSPLIT utility is used (see manual).

lo_prog.psm - First program used in kcpsm_split_rom design.  

hi_prog.psm - Second program used in kcpsm_split_rom design.

seven_segment_display.vhd - Also used in the kcpsm_split_rom design, but may also be useful
                            in other designs. Defines 4 slices to act as a 4-bit data to 
                            7-segment hexadecimal display decoder.

UART_Manual.pdf - Documentation of some simple UART transmitter and Receiver macros which are 
                  suitable for connection to the PicoBlaze Soft Processor.

uart_tx.vhd - UART transmitter, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer.
              Occupies 18 slices.

uart_rx.vhd - UART receiver, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer.
              Occupies 22 slices.

kcuart_tx.vhd - UART transmitter, 8-bit, no parity, 1 stop bit.
                Can be used standalone, but typically used as part of uart_tx.vhd.

kcuart_rx.vhd - UART receiver, 8-bit, no parity, 1 stop bit.
                Can be used standalone, but typically used as part of uart_rx.vhd.

bbfifo_16x8.vhd - A 16 byte synchronous FIFO buffer occupying 8 slices.
                  Used in uart_tx and uart_rx, but also useful standalone.


Additional Assembler Notes
--------------------------

Copy KCPSM.EXE into your working directory. You must also copy the template 
files ROM_form.vhd and ROM_form.coe into the same directory. Both template files 
are required, regardless of the design flow you intend to use.

You can modify the template files (see documentation), but no checking of syntax
is performed by the assembler.


-------------------------------------------------------------------------------
END OF FILE readme.txt
-------------------------------------------------------------------------------


