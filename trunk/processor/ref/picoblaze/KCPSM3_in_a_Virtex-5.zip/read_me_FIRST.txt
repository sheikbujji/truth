read_me_FIRST.txt file for using KCPSM3 with Virtex-5 Devices 
-------------------------------------------------------------

Date : 5th February 2010

Macro Version v1.30
Assembler Version v1.31
JTAG_Loader_6 Version v6.0

Operation confirmed with ISE v10.1 and ISE v11.4


**  Please take time to read the information in this document   **
**  BEFORE starting your first design with a Virtex-5 device.   **


Contents
  Purpose of this package
  The Principle Differences when targeting Virtex-5
  Documentation and Reference Designs
  Package contents - Design files and utilities
  JTAG_Loader_6
  Recommended Implementation Style for a Virtex-5 Design
  Additional Assembler Notes
  Potential synthesis issues



Purpose of this package
-----------------------

Although the 'KCPSM3' version of PicoBlaze was originally implemented specifically for the 
Spartan-3 device family it has been possible to use it with later products as they have been 
introduced. In fact, it has been possible to use KCPSM3 successfully in Spartan-3E, Spartan-3A,
Spartan-3AN and Virtex-4 devices with no impact to design flow or results. 

It is also possible to use KCPSM3 in Virtex-5, Virtex-6 and Spartan-6 devices. However, there 
are a few restrictions and special requirements when developing your design. This 'read_me_FIRST' 
file describes those steps that you should take to be successful with PicoBlaze in Virtex-5 
and the package provides you the files and tools that will work in this device.

Please note that if you are familiar with using PicoBlaze in previous devices then there are some 
changes to the development tools even though the actual KCPSM3 remains identical at this time.

If this is your first experience of PicoBlaze then please use the notes in this 'read_me_FIRST' 
file to define your design flow in cases that the original documentation differs. 



The Principle Differences when targeting Virtex-5 
-------------------------------------------------

More details are provided in the remainder of this 'read_me_FIRST' file but to emphasize the key points 
immediately here is a brief introduction.

The KCPSM3 hardware definition and assembler are unchanged so therefore the way in which you use 
KCPSM3 in your designs remains unchanged. The architecture of a Virtex-5 device is different 
to that of a Spartan-3 so you will see less logic Slices reported as being used.

JTAG_Loader_6 is a optional utility to change the PicoBlaze program in an active device. This will be of 
immense value during design and code development so it is highly recommended during that phase of design.
This is a new version of JTAG_Loader and it is recommended that this new version be used during the 
development of all new Virtex-5 designs even though the original JTAG loader can be made to work. The 
new version must be used when targeting Spartan-6 and Virtex-6 devices, and likewise, the original 
version must be used with Spartan-3 Generation devices. If you are familiar with the original version 
of JTAG_Loader then it is important that you read the new documentation as there are several differences 
to the way it is used and operates even though the overall concept is the same. More advanced users will 
be interested in the ability to reprogram multiple PicoBlaze contained in the same design.  

As of 5th February 2010 it is not possible to use DATA2MEM to change a PicoBlaze program in a 
Virtex-5 device. Please use JTAG_Loader_6 until this has been addressed.

Unfortunately, the ISE tools will be seen to generate warning messages similar to "Possible simulation 
mismatch" but these relate to changes in the synthesis tools over the years and not device architecture.
These warnings can safely be ignored and filtered if desired.



Documentation and Reference Designs
-----------------------------------
     
There is a variety of documentation and a significant number of reference designs available. 
This 'read_me_FIRST' file covers the specific requirements when implementing a PicoBlaze design 
in a Virtex-5 device. Likewise, the new 'JTAG_Loader_6' and its documentation included in this package
are required when using Virtex-5.

All other documentation is older and will show the versions of the ISE available at that time. Most of 
the reference designs are implemented on Spartan-3 Generation devices and boards. However, as far as the 
applications of PicoBlaze are concerned, the implementation of peripheral circuits and the general design 
flow are still applicable and valuable resources. If a reference design happens to include JTAG_Loader 
in its definition then you will need to replace this with JTAG_Loader_6 before targeting your Virtex-5
device (i.e. providing the new ROM_form tempate for the assembler and corresponding changes to the 
instantiation of the program ROM in the HDL design). 


In this package.....

  read_me_FIRST.txt - This file including the Virtex-5 specific requirements and recommendations.

  KCPSM3_Manual.PDF - Alternative documentation to UG129. 

  UART_Manual.pdf - Documentation for simple UART transmitter and Receiver macros which are 
                    suitable for connection to KCPSM3. These are used in many of the reference 
                    designs and users often express how useful they find these for communication 
                    within embedded applications as well as with external devices such as a PC.
                    Note that there are several USB/UART converters available on the market such 
                    as those from FDTI Chip (http://www.ftdichip.com/)

  UART9_readme.txt - A supplement to the above document describing a 9-bit UART and how it can be 
                     used with PicoBlaze to implement a UART with parity if required.

  JTAG_Loader_6_User_Guide.pdf - The user guide for the 'JTAG_Loader_6' utility.
                     This tool enables you to rapidly develop your PSM code using the device 
                     live on your board. This is normally the the best way to develop code 
                     being significantly quicker than simulation or ISE design iterations.
                     **  This is a new version of JTAG_Loader for Generation-6 devices.    **
                     **  Please read this carefully before starting your design especially **
                     **  if you have previously used the original version of JTAG_Loader.  **

  kcpsm3_int_test - Simple example used in the main documentation (files described below). 



On the web.....

  http://www.xilinx.com/support/documentation/ip_documentation/ug129.pdf
     UG129: PicoBlaze 8-bit Embedded Microcontroller User Guide.
     This is the main documentation for PicoBlaze.

  http://www.xilinx.com/products/boards/s3estarter/reference_designs.htm
     Reference Designs for the Spartan-3E Starter Kit with 13 including PicoBlaze.
     Each design has a corresponding PDF documentation showing the design implementation in 
     detail. Source files including VHDL and PicoBlaze PSM assembler code is provided containing 
     many comments.  

  http://www.xilinx.com/products/boards/s3estarter/reference_designs.htm
     Reference Designs for the Spartan-3A(N) Starter Kit with 9 including PicoBlaze.
     Each design has a corresponding PDF documentation showing the design implementation in 
     detail. Source files including VHDL and PicoBlaze PSM assembler code is provided containing 
     many comments.  

  http://forums.xilinx.com/xlnx/board?board.id=PicoBlaze
     The PicoBlaze Forum where you can enjoy discussions with other users.
     There are number of 'FAQ' threads covering many of the common issues and providing advice.

  Finally, try a general search of the web and you can be surprised at what you find.




Package contents - Design files and utilities
---------------------------------------------

This package contains many files, but don't panic, the files have been grouped into 
directories to help you find those that you need.


VHDL files.....


  kcpsm3.vhd. - The VHDL definition of the KCPSM3 processor. This is the hardware definition  
                of KCPSM3 PicoBlaze used in design implementation and simulation. 
                The use of this file is described in the documentation.

  embedded_kcspm3.vhd - VHDL file in which the KCPSM3 processor is connected to its 
                        associated program ROM. This can be used as example code and 
                        is described in the documentation.   
               
  kcpsm3_int_test.vhd - Example design VHDL file as used in the documentation.

  test_bench.vhd - Example VHDL test bench to use with kcpsm3_int_test.vhd to 
                   reproduce the wave forms seen in the documentation.

  uart_tx.vhd - UART transmitter, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer. 

  uart_rx.vhd - UART receiver, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer.
              
  kcuart_tx.vhd - UART transmitter, 8-bit, no parity, 1 stop bit. This is used in 'uart_tx.vhd'.
                  It could be used standalone but this is NOT recommended.

  kcuart_rx.vhd - UART receiver, 8-bit, no parity, 1 stop bit. This is used in 'uart_rx.vhd'.
                  It could be used standalone but this is NOT recommended.

  bbfifo_16x8.vhd - A 16 byte synchronous FIFO buffer. Used in 'uart_tx.vhd' and 'uart_rx.vhd'.
                    This can be used standalone or to expand the depth of the UART FIFO.  
                    See pages 26 and 27 of the following reference design for details of how to do this. 
                    http://www.xilinx.com/products/boards/s3astarter/files/s3ansk_flash_programmer.pdf

  uart9_tx.vhd - 9-bit UART transmitter with integral 16-character FIFO buffer.

  uart9_rx.vhd - 9-bit UART receiver with integral 16-character FIFO buffer.

  kcuart9_tx.vhd - 9-bit UART transmitter.

  kcuart9_rx.vhd - 9-bit UART receiver.

  bbfifo9_16x9.vhd - A 16 character synchronous FIFO buffer.





Verilog files....


  kcpsm3.v - The Verilog definition of the KCPSM3 processor. This is the hardware definition  
             of KCPSM3 PicoBlaze used in design implementation and simulation. 
             The use of this file is described in the documentation.

  embedded_kcspm3.v - Verilog file in which the KCPSM3 processor is connected to its 
                      associated program ROM. This can be used as example code and 
                      is described in the documentation.   
               
  kcpsm3_int_test.v - Example design Verilog file as used in the documentation.

  test_bench.v - Example Verilog test bench to use with kcpsm3_int_test.v to 
                 reproduce the wave forms seen in the documentation.

  uart_tx.v - UART transmitter, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer. 

  uart_rx.v - UART receiver, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer.
              
  kcuart_tx.v - UART transmitter, 8-bit, no parity, 1 stop bit. This is used in 'uart_tx.v'.
                It could be used standalone but this is NOT recommended.

  kcuart_rx.v - UART receiver, 8-bit, no parity, 1 stop bit. This is used in 'uart_rx.v'.
                It could be used standalone but this is NOT recommended.

  bbfifo_16x8.v - A 16 byte synchronous FIFO buffer. Used in 'uart_tx.v' and 'uart_rx.v'.
                  This can be used standalone or to expand the depth of the UART FIFO. 
                  See pages 26 and 27 of the following reference design for details of how to do this. 
                  http://www.xilinx.com/products/boards/s3astarter/files/s3ansk_flash_programmer.pdf




Assembler Files...

  **NOTE** As described in the main documentation you must have a valid copy of ROM_form.vhd, 
           ROM_form.v and ROM_form.coe in your working directory containing the KCPSM3 assembler.
           The assembler will generate .vhd, .v and .coe files and you then use the one you need.
           Your PSM file name must be 8 characters or less and it is recommended that your 
           working directory is on your local hard drive. If issues are encountered running 
           the assembler then also try running the assembler in directory with a shorter and 
           simple path.  

  kcpsm3.exe - The assembler for KCPSM3 programs.

  ROM_form.vhd - The default VHDL template file read by the assembler and used to define the 
                 style in which the program ROM will be implemented. 

  ROM_form.v - The default Verilog template file read by the assembler and used to define the 
               style in which the program ROM will be implemented.  

  ROM_form.coe - Coefficient template file read by the assembler and used to define contents 
                 for a program ROM implemented via the Core Generator flow. 

  cleanup.bat - A simple batch file to use after successful assembly of your code. 
                At the DOS prompt type 'cleanup <progname>' and this batch file
                will replace your PSM file with the formatted (FMT) file. It will
                maintain one copy of your original file as 'previous_<progname>.psm'.
 
  int_test.psm - Example PSM file as used in the documentation.




JTAG_Loader_6....

  ** At this time the JTAG_Loader_6 is provided in VHDL only. Verilog designers can exploit **
  ** mixed language synthesis by instantiating the JTAG_Loader_6 in their Verilog design.   **
  ** However, it is then vital that they remember to use the .vhd file generated by the     **
  ** assembler in their project.                                                            **


  JTAG_LOADER_6_single_ROM_form.vhd - The principle 'ROM_form.vhd' template to be used with the 
                                      assembler. Copy to your working directory and rename 'ROM_form.vhd'. 
                                      
  JTAG_LOADER_6.vhd - The loader circuits which are part of 'JTAG_LOADER_6_single_ROM_form.vhd'.
                      Advanced users can use this separately following the main documentation.

  JTAG_LOADER_6_multi_ROM_form.vhd - An alternative 'ROM_form.vhd' template to be used with the assembler.
                                     Advanced users will use this in conjunction with JTAG_LOADER_6.vhd
                                     when implementing designs containing multiple PicoBlaze instantiations.
                                     Copy to your working directory and rename 'ROM_form.vhd'.

  jtag_uploader.tcl - The principle TCL script for uploading a new PicoBlaze program to the device.
                      Copy to your working directory. See main document for instructions.

  jtag_loader.tcl - Used by jtag_uploader.tcl and must be copied to your working directory.

  jtag_loader_processes.tcl - Used by jtag_loader.tcl and must be copied to your working directory.

  jtag_downloader.tcl - The TCL script for reading back a PicoBlaze program from a device.
                        Useful for advanced verification. See main document for instructions.

  ml505.jtag6 - JTAG board configuration file for the Virtex-5 ML505 Evaluation Board.
                Must be copied to the working directory when this board is being targeted.
                Can be a useful starting point for your own board description file. See main document 
                for instructions on how to define your JTAG chain.
                
  ml507.jtag6 - JTAG board configuration file for the Virtex-5 ML507 Evaluation Board.
                Must be copied to the working directory when this board is being targeted.

  ml605.jtag6 - JTAG board configuration file for the Virtex-6 ML605 Evaluation Board.
                Must be copied to the working directory when this board is being targeted.

  sp605.jtag6 - JTAG board configuration file for the Spartan-6 SP605 Evaluation Board.
                Must be copied to the working directory when this board is being targeted.
                





Recommended Implementation Style for a Virtex-5 Design
------------------------------------------------------


The following extracts of code can be copied directly into your Virtex-5 design such that 
KCPSM3 PicoBlaze and its program memory are defined and connected. The code also provides the 
option to use the new JTAG_Loader_6 for code development.

The recommendation is that you use the JTAG_LOADER_6_single_ROM_form.vhd as your ROM_form.vhd
template so that the assembler always provides you with the option to use the JTAG loader. You 
can then enable or disable the JTAG loader via the simple C_JTAG_LOADER_DISABLE generic. When 
you disable the JTAG loader your implementation will only contain a simple single port ROM with 
absolutely no overhead and the reset signal will be tied Low automatically.

If you are familiar with the original JTAG_Loader, then you will appreciate that the generic 
avoids the requirement to switch between different ROM_form templates and the associated 
HDL changes to program ROM definition and connections.

  
Code for your component and signal declaration section.....

--
-- Component declaration of KCPSM3 PicoBlaze processor
--
  component kcpsm3 
    Port (      address : out std_logic_vector(9 downto 0);
            instruction : in std_logic_vector(17 downto 0);
                port_id : out std_logic_vector(7 downto 0);
           write_strobe : out std_logic;
               out_port : out std_logic_vector(7 downto 0);
            read_strobe : out std_logic;
                in_port : in std_logic_vector(7 downto 0);
              interrupt : in std_logic;
          interrupt_ack : out std_logic;
                  reset : in std_logic;
                    clk : in std_logic);
    end component;

--
-- Component declaration of program ROM with JTAG_Loader_6 option
--
-- This means that you copied JTAG_LOADER_6_single_ROM_form.vhd to your working 
-- directory and renamed it ROM_form.vhd before running the assembler.
-- The assembler then generated a VHD file with the same name as your PSM file. 
-- In these code examples <progname> is used to represent that name and would need
-- to be changed appropriately in your design.
--

  component <progname>
    generic( C_JTAG_LOADER_DISABLE : integer := 0;
                          C_FAMILY : string := "VIRTEX5");
    Port (      address : in std_logic_vector(9 downto 0);
            instruction : out std_logic_vector(17 downto 0);
            debug_reset : out std_logic;
                    clk : in std_logic);
    end component;



--
-- Typical signal names used to connect KCPSM3 to the program ROM and I/O logic
--

  signal address         : std_logic_vector(9 downto 0);
  signal instruction     : std_logic_vector(17 downto 0);
  signal port_id         : std_logic_vector(7 downto 0);
  signal out_port        : std_logic_vector(7 downto 0);
  signal in_port         : std_logic_vector(7 downto 0);
  signal write_strobe    : std_logic;
  signal read_strobe     : std_logic;
  signal interrupt       : std_logic;
  signal interrupt_ack   : std_logic;
  signal kcpsm3_reset    : std_logic;




Code for the main body of your design description......



--
-- Instantiation of the KCPSM3 PicoBlaze processor
--

  processor: kcpsm3
    port map(      address => address,
               instruction => instruction,
                   port_id => port_id,
              write_strobe => write_strobe,
                  out_port => out_port,
               read_strobe => read_strobe,
                   in_port => in_port,
                 interrupt => interrupt,
             interrupt_ack => interrupt_ack,
                     reset => kcpsm3_reset,
                       clk => clk);
 
--
-- Instantiation of the program ROM with JTAG_Loader_6 option.
--
-- The option to include the JTAG_Loader_6 circuits is controlled by the 
-- 'C_JTAG_LOADER_DISABLE' generic. Set as required and then synthesize the design.
-- Note that only one PicoBlaze program memory of this type can be JTAG_Loader 
-- enabled at a time. Please read the detailed documentation for advanced techniques 
-- supporting multiple PicoBlaze in the same design. 
--
--  C_JTAG_LOADER_DISABLE => 0,      JTAG_Loader_6 option available for code development.
--  C_JTAG_LOADER_DISABLE => 1,      Simple single port ROM will be implemented
--                                   (This is normally set before final production). 
--

  program_rom: <progname> 
    generic map ( C_JTAG_LOADER_DISABLE => 0,
                               C_FAMILY => "VIRTEX5")
    port map(      address => address,
               instruction => instruction,
               debug_reset => kcpsm3_reset,
                       clk => clk);




Additional Assembler Notes
--------------------------

Copy KCPSM3.EXE into your working directory. You must also copy the template 
files ROM_form.vhd, ROM_form.v and ROM_form.coe into the same directory. All template 
files are required, regardless of the design flow you intend to use.

You can modify the template files (see documentation), but no checking of syntax
is performed by the assembler. The JTAG loader uses different templates which are 
provided.

The assembler is only a simple DOS based utility. File names have a limit of 8-characters
and care should be taken not to use in a project directory with a very deep hierarchy 
requiring a long path specification. If you encounter an unexpected failure, please 
attempt to assemble you program in a simple directory such as c:\temp to determine if 
the problem is related to these DOS limitations. 

The assembler is normally used by first opening a DOS window in the working directory
and then executing KCPSM3 from within that window (please see KCPSM3_Manual.pdf). 
Attempting to execute KCPSM3.EXE directly from within Windows will only cause a DOS 
box to be displayed momentarily providing no opportunity to enter a PSM file name.

It is highly recommended that all files required by the assembler are located in the 
same working directory. Users have been successful using this utility on various networks
but the author will not support or address any issues related to any difficulties 
resulting from using KCPSM3 in this way.

To redirect the DOS screen output to a file the > symbol can be used in the DOS 
command line. 

C:\DESIGN>kcpsm3 simple > screen_dump.txt




INST Directive

The assembler also has an 'INST' directive which allows the definition of any instruction 
code in line with the existing instructions. The INST directive has only one operand which 
must be a 5 digit hexadecimal value in the range 00000 to 3FFFF corresponding to the 18-bit 
instruction memory formed in a Block RAM.

Examples of valid syntax for INST directive

    INST 3245C
    INST 14FA2
    inst 2abfe

This directive was included to enable data to be embedded within the program memory space 
which can then be accessed via the second port of the dual port Block RAM. The INST directives 
will normally be preceded by the ADDRESS directive to locate such data at a predictable 
location within the memory space.

Obviously great care should be taken to ensure that data values are not encountered by KCPSM3 
during normal operation as the macro does not support illegal op-code trapping.
 





Potential synthesis issues
--------------------------

The HDL supplied for the KCPSM3 macro and the HDL generated by the assembler 
(derived from the ROM_form templates) has been written to be suitable for both 
synthesis and simulation. 

In order for a simulator to have the correct information, the code includes 'INIT'
values defined using 'generic map' statements for each primitive component.
Synthesis tools also require the 'INIT' values to be defined, but in this case the 
definition is performed using a separate 'attribute' statements'. The synthesis tool 
must then be instructed to ignore the 'generic map' information which is achieved
using meta command directives. Unfortunately, there is no real standard for these 
directives and different synthesis tools will expect slightly different syntax.

The supplied HDL has been written using the directives '--synthesis translate_off'
and '--synthesis translate_on' and can be seen in the code as shown in this example:-

  t_state_lut: LUT1
  --synthesis translate_off
    generic map (INIT => X"1")         
  --synthesis translate_on
  port map( I0 => t_state,
             O => not_t_state );

If your synthesis tool reports any issues with processing the 'INIT' values declared 
as part of the 'generic map' statements then it is not ignoring these lines as intended.
In this case you should globally replace the directives in the 'kcpsm3' and 
'ROM_form' files to match the requirements of your synthesis tool. The syntax 
variants of this meta command directive encountered by the author are as follows:-

--translate_off                --translate_on 
--synthesis translate_off      --synthesis translate_on
--synopsys translate_off       --synopsys translate_on
--pragma translate_off         --pragma translate_on

XST is able to interpret all of the above variants so '--synthesis translate_off'
and '--synthesis translate_on' have been used in the supplied code because it is
the most frequently acceptable variant by other synthesis tools.

If your synthesis tool reports any issues with processing the attribute 'INIT' values 
then it may be possible to delete all the attributes providing the synthesis translate_off
and synthesis translate_on directives are also removed. In this way the generic is 
serving both sythesis and simulation but may not work with all tools especially 
older versions.



How to filter Warnings.....

With warning messages similar to 'WARNING:Xst:2185' which report a "Possible simulation mismatch"
being safe to ignore it can be desirable to use the ISE warning filter facility.....

In Project navigator -> Edit -> Message Filters... 
    Check the box next to 'Filter enabled' and then save using File -> Save

Then return to your project and run XST again and when you return to the message filters window 
you will find that all the warning messages have appeared in the lower half of the screen.
Move any one of the XST warning messages into the top window (Click once on message to select
it and then click and drag it to the top window).

In the top window, select the box under 'Filter Text' and right click to choose the 'Delete'
option. This will change the text to read "blank" line "blank": Possible... etc. Now this one
filter will remove all of the warnings of that type in one go.

Save the changes with File -> Save.

Now when running XST again all of the messages of the type(s) identified will have been removed.



-------------------------------------------------------------------------------
End of read_me_FIRST.txt
-------------------------------------------------------------------------------


