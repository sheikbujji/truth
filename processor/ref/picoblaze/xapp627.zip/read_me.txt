READ_ME.TXT file for KCPSM2
---------------------------

Release 6.   August 2003

Macro Version v1.40
Assembler Version v1.20

This is the second official release of PicoBlaze for Virtex-II and Virtex-IIPro devices 
consistent with the publication of XAPP627 (v1.1) dated February 4, 2002.

IMPORTANT NOTE - This package includes support for a Verilog design flow for the first time.
Please take the time to read all of this readme.txt file to identify the differences with the 
existing documentation. Verilog users should take particular notice of the 'Verilog Design Notes'.


Author
------

Ken Chapman
email: chapman@xilinx.com 
Staff Engineer - Applications Specialist
Xilinx Ltd (UK)

With many thanks to Joel Coburn (APD Applications - Xilinx Inc) for all Verilog translations.

      
Quick Description
-----------------

KCPSM2 is a very simple 8-bit micro controller designed to be 100% embedded into a 
Virtex-II or Virtex-IIPRO device and is based on the popular KCPSM (also known as picoBlaze)
for Virtex(E) and Spartan-II devices (See XAPP213).

It features 32 general purpose registers. A simple ALU supporting ADD/SUB,
logical, shifts and rotates, conditional jumps and nested subroutine calls.
Controls include a reset and an interrupt with associated instructions. 

The KCPSM2 assembler is supplied to assist in the development of programs. 

Performance >45 MIPS. Best of all, it uses just 84 slices 
(fit 2 in an XC2V40  and still have 34% of the device left over).

Documentation is provided by XAPP627 and this file.

Note : A new variant of PicoBlaze called KCPSM3 has been developed which can also be 
used with Virtex-II and Virtex-IIPRO devices. This new variant has the advantage that 
it is also suitable for Spartan-3 devices as well as supporting some additional 
instructions. It is therefore highly recommended that this new variant should be 
reviewed and considered before commencing any new designs.
 

Verification and Testing
------------------------

This is the sixth release of KCPSM2. With over 1000 users of the VHDL version of 
the macro and assembler over a period of more 18 months, there is now high confidence that
this is a fully working solution. Since it is virtually impossible to verify every 
combination of events that a processor may encounter, your help is requested in 
continuing to verify the functionality of the macro and assembler. All reports are 
welcomed by the author (hopefully good reports as well as any issues or recommendations). 

IMPORTANT: This is the first release of the Verilog files and any feedback on the use of 
these files is particularly valuable.

Please send your reports via email to: chapman@xilinx.com

 
KCPSM2 Macro Revision History (VHDL)
------------------------------------

V1.00 - First release to users - December 2001.
V1.10 - Improved formatting of text. No logical changes.
V1.20 - Improved formatting of text. No logical changes.
V1.30 - Moved main KCPSM2 entity to the end of file to match compile order requirements
        of certain synthesis and simulation tools.  No logical changes.
V1.31 - Deleted the word 'is' where not required in definition of some components. No logical changes.
V1.40 - Change of '--translate off' and '--translate on' meta command directives to 
        '--synthesis translate off' and '--synthesis translate on'. 
        Improvement to filename handling. No logical changes.


KCPSM2 Macro Revision History (Verilog)
---------------------------------------

V1.00 - First release to users - August 2003.


KCPSM2 Assembler Revision History
---------------------------------

V1.02  - First release to users with improved (and corrected) template files.
V1.03  - Added generation of '<filename>.hex' and '<filename>.dec' files.
         Name of formatted output file changed to '<filename>.fmt'.         
V1.04  - Minor modifications to error messages.
V1.10  - Correction to support programs in which only one line label is used.
V1.12  - Enhancements to error messages.
V1.20  - Support of Verilog and System Generator design flows.


Contents
--------

This package contains many files, but don't panic, many of them are additional 
files which I hope you will find useful reference.


Main KCPSM2 Files
-------------------

This package contains the following files.....


READ_ME.TXT - This file

kcpsm2.vhd - The VHDL definition of the KCPSM2 processor. This file is the 
             primary design flow for implementation and simulation. The use of 
             this file is described in the documentation.

kcpsm2.v - The Verilog definition of the KCPSM2 processor.
           Please see 'Verilog Design Notes' in this file.

kcpsm2.ngc - This is an alternative file defining the KCPSM2 processor and 
             would be used as a 'black box' in a non VHDL or Verilog design flow.
               
KCPSM2.EXE - The assembler for KCPSM2 programs.

ROM_form.vhd - VHDL template file read by the assembler and used to define the 
               style in which the program ROM will be implemented. This file 
               must be placed in the same working directory as KCPSM2.EXE.

ROM_form.v - Verilog template file read by the assembler and used to define the 
             style in which the program ROM will be implemented. This file 
             must be placed in the same working directory as KCPSM2.EXE.

ROM_form.coe - Coefficient template file read by the assembler and used to define
               the style in which the program ROM will be implemented via the 
               Core Generator flow. This file must be placed in the same working
               directory as KCPSM2.EXE.

KCPSM3 Reference and support files
----------------------------------

kcpsm2_embedded - VHDL file in which the KCPSM2 processor is connected to its 
                  associated program ROM. This can be used as example code and 
                  is described in the documentation.  

int_test.psm - Example PSM file as used in the documentation.

kcpsm2_int_test.vhd - Example design VHDL file as used in the documentation.

test_bench.vhd - Example VHDL test bench to use with kcpsm2_int_test.vhd to 
                 reproduce the wave forms seen in the documentation.


Bonus Files
-----------

seven_segment_display.vhd - Defines 4 slices to act as a 4-bit data to 7-segment hexadecimal display decoder.

UART_Manual.pdf - Documentation of some simple UART transmitter and Receiver macros which are 
                  suitable for connection to KCPSM-II.

uart_tx.vhd - UART transmitter, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer.
              Occupies 18 slices.

uart_rx.vhd - UART receiver, 8-bit, no parity, 1 stop bit, with integral 16-byte FIFO buffer.
              Occupies 22 slices.

kcuart_tx.vhd - UART transmitter, 8-bit, no parity, 1 stop bit.
                Can be used standalone, but typically used as part of uart_tx.vhd.

kcuart_rx.vhd - UART receiver, 8-bit, no parity, 1 stop bit.
                Can be used standalone, but typically used as part of uart_rx.vhd.

bbfifo_16x8.vhd - A 16 byte synchronous FIFO buffer occupying 8 slices.
                  Used in uart_tx and uart_rx, but also useful standalone.


Additional Assembler Notes
--------------------------

The assembler is now able to generate a Verilog file defining the program memory for 
use in a Verilog design flow. The Verilog file is generated by the assembler by reading 
a 'ROM_form.v' template file and modifying the contents (the same process is used
in the generation of the VHDL output by modifying the 'ROM_form.vhd' file). You may 
edit the template to change the format of the memory, but you are responsible for the 
validity of the Verilog as no checking of syntax is performed by the assembler.

The assembler also generates an 'm-file' function which is used in the MatLab Simulink 
design flow with Xilinx System Generator.  

Copy KCPSM2.EXE into your working directory. You must also copy the template files 
ROM_form.vhd, ROM_form.v and ROM_form.coe into the same directory. ALL template files 
are required, regardless of the design flow you intend to use.

You can modify the template files (see documentation), but no checking of syntax
is performed by the assembler.

The assembler is only a simple DOS based utility. File names have a limit of 8-characters
and care should be taken not to use in a project directory with a very deep hierarchy 
requiring with a long path description. If you encounter an unexpected failure, please 
attempt to assemble you program in a simple directory such as c:\temp to determine if 
the problem is related to these DOS limitations. 

The assembler is normally used by first opening a DOS window in the working directory
and then executing KCPSM2 from within that window (please see KCPSM3_manual.pdf). 
Attempting to execute KCPSM2.EXE  directly from within Windows will only cause a DOS 
box to be displayed momentarily providing no opportunity to enter a PSM file name.

It is highly recommended that all files required by the assembler are located in the 
same working directory. Users have been successful using this utility on various networks
but the author will not support or address any issues related to any difficulties 
resulting from using KCPSM3 in this way.

To redirect the DOS screen output to a file the > symbol can be used in the DOS 
command line. 

C:\DESIGN>kcpsm2 simple > screen_dump.txt


Verilog Design Notes
--------------------

The vast majority of the KCPSM2 documentation is valid for all design flows. Although the 
documentation is primarily focussed on the VHDL flow, it is hoped that the Verilog design flow
is adequately similar that it should be possible for existing users of Verilog to target Xilinx
devices will be able to make the appropriate adjustments. If you are not familiar with Verilog 
or Xilinx design flows, then it is recommended that you do NOT use PicoBlaze until you have 
gained some experience.


The following Verilog component intantiations should be used to include the KCPSM2 macro and 
program memory generated by the assembler into your design. As long as the source files 
'kcpsm2.v' and 'prog_rom.v' are in the same directory or project, they will be compiled and recognized 
in the project. Note that 'prog_rom.v' will be given the same name as your program (.psm) file.
 

// Instantiate Picoblaze Module 

kcpsm2 kcpsm2_instance_name( 
  .address (address),     //O 
  .instruction (instruction),     //I 
  .port_id (port_id),     //O 
  .write_strobe (write_strobe),     //O 
  .out_port (out_port),     //O 
  .read_strobe (read_strobe),     //O 
  .in_port (in_port),     //I 
  .interrupt (interrupt),      //I 
  .reset (reset),     //I 
  .clk  (clk)     //I 
  ); 

// Instantiate Instruction RAM Module 

prog_rom prog_rom_instance_name( 
   .address(address),  //I 
   .clk(clk),   //I 
   .instruction(instruction)  //O 
   ); 


-------------------------------------------------------------------------------
END OF FILE READ_ME.TXT
-------------------------------------------------------------------------------


